package com.example.simplecalculator.InfixToPostfix;

public class StackCh {
    public char array[];
    public int top;
    public int size;

    public StackCh(int len){
        size = len;
        array = new char[size];
        top = -1;
    }
    public void push(char c){
        array[++top] = c;
    }
    public char pop(){
        return array[top--];
    }
    public char peek(){
        return array[top];
    }
    public boolean isEmpty(){
        return (top == -1);
    }

}




