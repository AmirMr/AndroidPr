package com.example.simplecalculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


import com.example.simplecalculator.InfixToPostfix.Calculator;
import com.example.simplecalculator.InfixToPostfix.InToPos;

import java.util.ArrayList;

public class CalculatorController extends AppCompatActivity {
    public TextView display;
    public Button equalButton;
    public Button AC;
    public Button delete;
    private static final String INDEX = "index";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.displayText);
        if (savedInstanceState != null){
            display.setText(savedInstanceState.getString(INDEX));
        }
        equalButton = findViewById(R.id.buttonEquals);
        AC = findViewById(R.id.buttonAC);

        delete = findViewById(R.id.Del);

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = display.getText().toString();
                if (text.length() > 0)
                    display.setText(text.substring(0,text.length()-1));
            }
        });

        equalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = display.getText().toString();
                InToPos in = new InToPos(text);

                ArrayList<String> posText = in.doTrans();
                Calculator calculate = new Calculator(posText);
                float res = calculate.doCalculation();
                display.setText(String.valueOf(res));
            }
        });
        AC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display.setText("0");
            }
        });
    }
    public void digitPressed(View v){
        Button target = (Button) v;
        String current = display.getText().toString();


        if (current.equals("0") && target.getText().toString().charAt(0) != '.'){
            current = "";
        }

        String text = current + target.getText().toString();
        display.setText(text);
    }
    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putString(INDEX, display.getText().toString());
    }
}
