package com.example.simplecalculator.InfixToPostfix;

import android.util.Log;

public class StackX {
    private int maxSize;
    private float[] stackArray;
    private int top;
    public StackX(int max){
        stackArray = new float[max];
        maxSize = max;
        top = -1;
    }
    public void push(float elem){
        stackArray[++top] = elem;
    }
    public float pop(){

        return stackArray[top--];
    }
    public float peek(){
        return stackArray[top];
    }
    public boolean isEmpty(){
        return (top == -1);
    }
    public boolean isFull(){
        return (top == maxSize-1);
    }
}
