package com.example.simplecalculator.InfixToPostfix;

import java.util.ArrayList;
import java.util.Scanner;

public class InToPos {

    private StackCh theStack;
    private String input;
    private ArrayList output;
    private String temp;
    public InToPos(String input) {
        this.input = input;
        theStack=new StackCh(input.length());
        output= new ArrayList();
        temp = "";
    }
    public ArrayList<String> doTrans(){
        for (int i=0;i<input.length();i++){
            char ch=input.charAt(i);
            if (Character.isDigit(ch) || (i==0 && input.charAt(i) == '-')){
                temp+=ch;
                while (i+1 < input.length() && (Character.isDigit(input.charAt(i+1)) || input.charAt(i+1)=='.')){
                    temp = temp + input.charAt(++i);
                }
                output.add(temp);
                temp = "";
            }else {
                switch (ch) {
                    case '+':
                    case '-':
                        gotOper(ch, 1);
                        break;
                    case '*':
                    case '/':
                        gotOper(ch, 2);
                        break;
                    case '(':
                        theStack.push('(');
                        break;
                    case ')':
                        gotParent();
                        break;
                }
            }
        }
        while (!theStack.isEmpty()){
            char c=theStack.pop();
            output.add(c+"");
        }
        return output;
    }
    public void gotOper(char opThis,int prec1){
        while (!theStack.isEmpty()){
            char opTop=theStack.pop();

            if (opTop=='('){
                theStack.push(opTop);
                break;
            }else {
                int prec2;
                if (opTop=='+' || opTop=='-'){
                    prec2=1;
                }else {
                    prec2=2;
                }
                if (prec2 < prec1){
                    theStack.push(opTop);
                    break;
                }else {
                    output.add(opTop+"");
                }
            }
        }
        theStack.push(opThis);
    }
    public void gotParent(){
        while (!theStack.isEmpty()){
            char ch=theStack.pop();
            if (ch=='('){
                break;
            }else {
                output.add(ch+"");
            }
        }
    }
    public static void main(String[] args) {
        Scanner in =new Scanner(System.in);
        String input=in.next();

        InToPos intopost=new InToPos(input);

        ArrayList<String> output=intopost.doTrans();

        for (int i = 0; i < output.size(); i++){
            System.out.print(output.get(i) + " ");
        }

    }
}
















