package com.example.simplecalculator.InfixToPostfix;

import java.util.ArrayList;

public class Calculator
{
    private StackX theStack;
    private ArrayList<String> input;

    public Calculator(ArrayList<String> s) {
        input = s;
    }
    public float doCalculation()
    {
        theStack = new StackX(20);
        String ch;
        int j;
        float num1, num2, interAns;
        for(j=0; j<input.size(); j++)
        {
            ch = input.get(j);
            if(Character.isDigit(ch.charAt(0)) || ((j==0) && input.get(j).charAt(0) == '-'))
                theStack.push(Float.parseFloat(ch));
            else
            {
                num2 = theStack.pop();
                num1 = theStack.pop();
                switch(ch.charAt(0))
                {
                    case '+':
                        interAns = num1 + num2;
                        break;
                    case '-':
                        interAns = num1 - num2;
                        break;
                    case '*':
                        interAns = num1 * num2;
                        break;
                    case '/':
                        interAns = num1 / num2;
                        break;
                    default:
                        interAns = 0;
                }
                theStack.push(interAns);
            }
        }
        interAns = theStack.pop();
        return interAns;
    }

}
