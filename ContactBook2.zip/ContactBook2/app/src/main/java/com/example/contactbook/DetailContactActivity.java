package com.example.contactbook;
import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
public class DetailContactActivity extends AppCompatActivity {
    ImageView photo;
    TextView name;
    TextView phoneNumber;
    static final int REQUEST_CALL = 1;
    ImageView makeCall;
    ImageView sendMessage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        photo = findViewById(R.id.contactImage);
        name = findViewById(R.id.contactName);
        phoneNumber = findViewById(R.id.phoneNumber);
        makeCall = findViewById(R.id.makeCall);
        sendMessage = findViewById(R.id.sendMessage);
        makeCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                makePhoneCall();
            }
        });
        sendMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(DetailContactActivity.this, SendMessage.class);
                Bundle b = new Bundle();
                b.putString("name", name.getText().toString());
                b.putString("phoneNumb", phoneNumber.getText().toString());
                i.putExtras(b);
                startActivity(i);
            }
        });
        Bundle bundle=getIntent().getExtras();

        if (bundle!=null){
            photo.setImageResource(bundle.getInt("contactImg"));
            name.setText(bundle.getString("contactName"));
            phoneNumber.setText(bundle.getString("contactPhoneNumber"));
        }
    }
    private void makePhoneCall() {
        String number = phoneNumber.getText().toString();
        if (number.trim().length() > 0){
            if (ContextCompat.checkSelfPermission(DetailContactActivity.this, Manifest.permission.CALL_PHONE)
                    != PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(DetailContactActivity.this,new String[]{Manifest.permission.CALL_PHONE},REQUEST_CALL);
            }else {
                String dial = "tel:"+number;
                Intent i = new Intent(Intent.ACTION_CALL, Uri.parse(dial));
                startActivity(i);
            }
        }
    }

    public static Intent newIntent(Context content, ArrayList<Contact> contacts, int position){
        Intent i = new Intent(content, DetailContactActivity.class);
        i.putExtra("contactImg", contacts.get(position).getImage());
        i.putExtra("contactName", contacts.get(position).getName());
        i.putExtra("contactPhoneNumber", contacts.get(position).getPhoneNumber());
        return i;
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_CALL){
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                makePhoneCall();
            }else {
                Toast.makeText(this,"Permission DENIED",Toast.LENGTH_SHORT).show();
            }
        }
    }
}
















