package com.example.contactbook;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView listV;
    ArrayList<Contact> contacts;
    CustomAdapter customAdapter;
    public DatabaseHelper myDB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listV = findViewById(R.id.listView);
        contacts = new ArrayList<>();
        addContacts();
        myDB = new DatabaseHelper(this);
        Cursor data = myDB.getListContents();
        if (data.getCount() > 0){
            while (data.moveToNext()){
                String[] arr = (data.getString(1)).split(" ");
                int a = Integer.parseInt(data.getString(0));
                contacts.add(new Contact(a,arr[0],arr[1],R.drawable.user2));
            }
        }

        customAdapter = new CustomAdapter(this,contacts);
        listV.setAdapter(customAdapter);

        listV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent i = DetailContactActivity.newIntent(MainActivity.this,contacts,position);
                startActivity(i);
            }
        });
        registerForContextMenu(listV);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.delete_menu,menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        switch (item.getItemId()){
            case R.id.delete_but:
                myDB.deleteName(contacts.get(info.position).getId(), contacts.get(info.position).getName());
                contacts.remove(info.position);
                customAdapter.notifyDataSetChanged();
                return true;
                default:
                 return super.onContextItemSelected(item);
        }
    }

    public void addContacts(){

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.add_Contact:
                startActivity(new Intent(MainActivity.this, AddOption.class));
                return true;
            case R.id.settings:

                return true;
            default:
                return super.onOptionsItemSelected(item);

        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.app_menu, menu);
        return super.onCreateOptionsMenu(menu);

    }
}













