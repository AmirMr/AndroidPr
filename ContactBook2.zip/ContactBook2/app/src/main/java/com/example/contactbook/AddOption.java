package com.example.contactbook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class AddOption extends AppCompatActivity {
    ImageView image;
    EditText nameSurname;
    EditText phoneNum;
    Button add;
    Button view;
    DatabaseHelper myDB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        image = findViewById(R.id.userPhoto);
        nameSurname = findViewById(R.id.userName);
        phoneNum = findViewById(R.id.userPhoneNumber);
        add = findViewById(R.id.addButton);
        view = findViewById(R.id.viewButton);
        myDB = new DatabaseHelper(this);


        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameSurname.getText().toString();
                String phoneNumber = phoneNum.getText().toString();

                if (name.length() == 0 || phoneNumber.length() == 0){
                    Toast.makeText(AddOption.this, "Invalid Input", Toast.LENGTH_SHORT).show();
                }else {
                    addData(name + " " + phoneNumber);
                }
            }
        });
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AddOption.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
    public void addData(String newData){
        boolean b=myDB.addData(newData);
        if (b){
            Toast.makeText(AddOption.this,"Added",Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(AddOption.this,"not Added",Toast.LENGTH_SHORT).show();
        }
    }
}













