package com.example.contactbook;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SendMessage extends AppCompatActivity {
    EditText textT;
    Button sendB;
    Button getBackB;
    static final int REQUEST_MESSAGE = 2;

    TextView theNames;
    TextView thePhoneNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_message);

        textT = findViewById(R.id.textW);
        sendB = findViewById(R.id.send);
        getBackB = findViewById(R.id.getBack);

        theNames = findViewById(R.id.theName);
        thePhoneNumber = findViewById(R.id.theNumber);

        Bundle bundle = getIntent().getExtras();

        if (bundle != null){
            theNames.setText(bundle.getString("name"));
            thePhoneNumber.setText(bundle.getString("phoneNumb"));
        }

        getBackB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(SendMessage.this, DetailContactActivity.class);
                startActivity(i);
            }
        });
        sendB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMessageMethod();
            }
        });
    }
    private void sendMessageMethod(){
        if (!checkPermission(Manifest.permission.SEND_SMS)){
            ActivityCompat.requestPermissions(SendMessage.this,new String[]{Manifest.permission.SEND_SMS},REQUEST_MESSAGE);
        }

        String smsMessage = textT.getText().toString();
        String phoneN = thePhoneNumber.getText().toString();

        if (checkPermission(Manifest.permission.SEND_SMS)){
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneN,null,smsMessage,null,null);
            Toast.makeText(this,"Message Is Sent!",Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(this,"Permission denied", Toast.LENGTH_SHORT).show();
        }
    }
    private boolean checkPermission(String permission){
        int check= ContextCompat.checkSelfPermission(this,permission);
        return check== PackageManager.PERMISSION_GRANTED;
    }
}
